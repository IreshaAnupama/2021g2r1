# E-Net -English Learning Platform
E-net English Learning Platform is made for Beginner learners who need to learn English properly and free.
</b>.<br><br>
Knowing English increases your chances of getting a good job in a multinational company within your home country or for finding work abroad. It's also the language of international communication, the media and the internet, so learning English is important for socialising and entertainment as well as work!
<br><br>
Team Members
<li>Sachintha Chathuranga
<li>Isuru Wimalasiri
<li>Sasanka Vikum
<li>Amila Upendra
<li>Salith Dilshan
<li>Arunoda Jayasundara
<li>Iresha Anupama
<li>Piyumika Gunarathne
<li>Kasuni Dulanga
